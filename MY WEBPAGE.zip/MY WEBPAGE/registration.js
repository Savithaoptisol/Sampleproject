function registration()
{

    var name= document.getElementById("t1").value;
    var email= document.getElementById("t2").value;
    var uname= document.getElementById("t3").value;
    var pwd= document.getElementById("t4").value;			
    var cpwd= document.getElementById("t5").value;
    var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,12}$/;
    var uname_exp = /^[A-Za-z0-9].{2,12}$/;
    var name_exp= /^[A-Za-z].{2,20}$/;
    var email_exp = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var result1=document.getElementById("spn1");
    var result2=document.getElementById("spn2");
    var result3=document.getElementById("spn3");
    var result4=document.getElementById("spn4");
    var result5=document.getElementById("spn5");
//name
    if(name=='')
    {
        result1.innerHTML='Please enter your name';
        return false;
    }
    else if(!name_exp.test(name))
    {
        result1.innerHTML=('User name field required only alphabet characters & atleast 3 Char');
        return false;
    }
    //email
    else if(email=='')
    {
        result2.innerHTML=('Please enter your user email id');
        return false;
    }
    else if (!email_exp.test(email))
    {
        result2.innerHTML=('Invalid email');
        return false;
    }
    //username
    else if(uname=='')
    {
        result3.innerHTML=('Please enter the user name.');
        return false;
    }
    else if(!uname_exp.test(uname))
    {
        result3.innerHTML=('Must have atleast 3 char & not exceed 12 char');
        return false;
    }
    //password
    else if(pwd=='')
    {
        result4.innerHTML=('Please enter Password');
        return false;
    }
    //confirmpassword
    else if(cpwd=='')
    {
        result5.innerHTML=('Enter Confirm Password');
        return false;
    }
    else if(!pwd_expression.test(pwd))
    {
        result4.innerHTML=('Must Satisfy => Upper case,Lower case,Special char,8 char to 12 char');
        return false;
    }
    else if(pwd!= cpwd)
    {
        result5.innerHTML=('Password not Matched');
        return false;
    }
    /*else if(document.getElementById("t5").value.length < 8)
    {
        result4.innerHTML= ('Password minimum length is 8');
        return false;
    }
    else if(document.getElementById("t5").value.length > 12)
    {
        result4.innerHTML=('Password max length is 12');
        return false;
    }*/
    else
    {				                            
        return true;
    }
}
    function readURL(input) {
        if (input.files.length > 0) {
          var reader = new FileReader();
          var expandImg = document.getElementById("Profile");
       
          const fsize = input.files[0].size;
          const file = Math.round(fsize / 1024);
          console.log(fsize);
          console.log(file);
          if (file >= 500) {
            alert("File too Big, please select a file less than 500Kb");  
            input.value = '';
            expandImg.src = "img/profileimg.jpg"
          } 
          else if (file < 6) {
            alert("File too small, please select a file greater than 6kb");
            input.value = '';
            expandImg.src = "img/profileimg.jpg"
          } 
          else {
          var filespan = document.getElementById("profilesize")
        
            reader.onload = function (e) {
              expandImg.src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
            filespan.innerHTML =""
          }
        }
        

}
function clearFunc()
{
    document.getElementById("t1").value="";
    document.getElementById("t2").value="";
    document.getElementById("t3").value="";
    document.getElementById("t4").value="";
    document.getElementById("t5").value="";
    expandImg.src = "img/profileimg.jpg";

}


  