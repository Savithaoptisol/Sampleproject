function login()
{
    var uname= document.getElementById("t1").value;
    var pwd= document.getElementById("t2").value;			
    var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,12}$/;
    var Uname_exp = /^[A-Za-z0-9].{2,12}$/;
    var result1=document.getElementById("log1");
    var result2=document.getElementById("log2");
//username
    if(uname=='')
    {
        result1.innerHTML='Please enter your name';
        return false;
    }
    else if(!Uname_exp.test(uname))
    {
        result1.innerHTML=('Must have atleast 3 char & not exceed 12 char');
        return false;
    }
//password
    else if(pwd=='')
    {
        result2.innerHTML=('Please enter Password');
        return false;
    }
    else if(!pwd_expression.test(pwd))
    {
        result2.innerHTML=('Must Satisfy => Upper case,Lower case,Special char,Numeric letter & 8 char to 12 char');
        return false;
    }
    /*else if(document.getElementById("t2").value.length < 8)
    {
        result2.innerHTML= ('Password minimum length is 8');
        return false;
    }
    else if(document.getElementById("t2").value.length > 12)
    {
        result2.innerHTML=('Password max length is 12');
        return false;
    }*/
    else
    {				                            
        return true;
    }
}