import { Component } from "@angular/core";

@Component({
    selector:'question-root',
    template:'<h1>This is our Question</h1>',
    styles: ['h1 { font-weight: normal; }']
})
export class QuestionComponent{

}