import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class CommonService {
  readonly APIUrl = "https://localhost:44394";
  currentUser: any;

  constructor(private http:HttpClient,private router:Router) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  getUserList():Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/Users/GetAllUsers')
  }
  getUsersbyId(Id:any):Observable<any> {   
      return this.http.get<any>(this.APIUrl + '/api/Users/'+Id)}


  DisplayUserListByFilter(val:any):Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/Users/GetAllUsers'+val)
  }
  addUserList(val:any):Observable<any>{
    return this.http.post<any>(this.APIUrl + '/api/Users/Register User',val)
  }

  editUserList(val:any):Observable<any>{
    return this.http.post<any>(this.APIUrl + '/api/Users/UpdateUser',val)
  }
  
  deleteUserList(val:any){
    return this.http.delete(this.APIUrl + '/api/Users/'+val)
  }

  GetStatus():Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/Status')
  }

  GetRoles():Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/Roles')
  }

  GetTeams():Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/TeamType')
  }

  GetManager(id:any):Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/Manager/'+id)
  }

  GetAllManagerList(id:any):Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/api/Users/GetAllManager'+id)
  }

  SaveImage(val:any):Observable<any>{

    let httpOptionsfor = {
  
      headers:  new HttpHeaders().set(
  
        'accept',
  
        'application/json'
  
      )
  
    }
  
     return this.http.post<any>(this.APIUrl+'/api/Users/SaveImage',val,httpOptionsfor)
  
   }




  // Sign-in
  signIn(user: any) {
    return this.http.post<any>(this.APIUrl + '/api/Authentication/login', user)
      .subscribe((res: any) => {
        alert("Login Successful")
        localStorage.setItem('access_token', res.token)
        this.getUserList().subscribe((res) => {
          this.currentUser = res;
          console.log(this.currentUser)
          this.router.navigate(['/Displayuser']);
          
        })
          

      },err=>{alert("Login Failed")})
  }

  getToken() {
    return localStorage.getItem('access_token');
  }

  get isLoggedIn(): boolean {
    let authToken = localStorage.getItem('access_token');
    return (authToken !== null) ? true : false;
  }

  doLogout() {
    let removeToken = localStorage.removeItem('access_token');
    if (removeToken == null) {
      this.router.navigate(['/login']);
    }
  }

  upload(file:any):Observable<any> {

 

    // Create form data
  
    const formData = new FormData();
  
     
  
    // Store form name as "file" with file data
  
    formData.append("file", file, file.name);
  
     
  
    // Make http post request over api
  
    // with formData as req
  
    return this.http.post(this.APIUrl , formData)
  
  }
}
