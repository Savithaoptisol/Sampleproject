import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  signinForm: FormGroup =new FormGroup({});
  submitted = false;


  constructor(  public fb: FormBuilder,
    public commonService:CommonService,
    public router: Router) { 
      
    }

  ngOnInit(): void {
    this.signinForm = this.fb.group({
    userName: ['',[Validators.required,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]],
    password: ['',[Validators.required]]
  })
  }
  get f(){return this.signinForm.controls;}

  OnSubmit(){
    this.submitted = true;
    var user={
      UserName:this.signinForm.get('userName')?.value,
      PassWord:this.signinForm.get('password')?.value
    }
    
      var res=this.commonService.signIn(user)
      console.log(user)
   
  }
  

}
