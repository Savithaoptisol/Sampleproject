import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/common.service';

@Component({
  selector: 'app-display-user',
  templateUrl: './display-user.component.html',
  styleUrls: ['./display-user.component.css']
})
export class DisplayUserComponent implements OnInit {
  user: any;
  title: string = "";
  UserList: any;
  ActiveAddEditEmpComp: boolean = false;
  Filter: any;
  CombinedData: any;
  result: any;
  DataInput: any;
  AdvanceFilter: any;
  ManagerList: any;
  size: number = 0;
  Page: number = 1;
  LastPage: boolean = true
  StartDate: any;
  EndDate: any;


  constructor(public service: CommonService, private router: Router) {
  }

  ngOnInit(): void {
    this.RefreshUser()
  }
  AddUser() {
    var newUser = {
      userId: 0,
      firstName: "",
      lastName: "",
      fullName: "",
      userName: "",
      address: "",
      status: "",
      role: "",
      joiningDate: "",
      previousOrganization: "",
      currentOrganization: "",
      experience: "",
      password: "",
      team: "",
      managerMail: ""


    }
    this.user = newUser;
    this.ActiveAddEditEmpComp = true;
    this.title = "Add User"
  }

  DeleteClick(id: any) {
    console.log(id)
    if (confirm('Are You Sure to Delete?')) {
      this.service.deleteUserList(id.userId).subscribe(data => {

        alert(data.toString());
        this.RefreshUser();
      })
    }

  }
  closeClick() {
    this.ActiveAddEditEmpComp = false;
    this.RefreshUser();

  }

  RefreshUser() {
    this.service.getUserList().subscribe(data => {
      console.log(data)
      let userlist=data
      this.UserList =userlist.reverse();
      localStorage.setItem("Employeedata", JSON.stringify(data))

    })
  }
  UpdateClick(DataItem: any) {
    this.title = "Edit User";
    this.ActiveAddEditEmpComp = true;
    this.user = DataItem;
    console.log(DataItem)

  }

  FilterOption(Firstinput: any) {
    this.Filter = Firstinput.target.value
    this.DataInput = []
    if (this.Filter == "Status") {
      this.service.GetStatus().subscribe(data => {
        this.DataInput = data
        this.AdvanceFilter = data[0].id
        console.log(this.DataInput)
      
      })
    }
    else if (this.Filter == "Roles") {
      this.service.GetRoles().subscribe(data => {
        this.DataInput = data
        this.AdvanceFilter = data[0].id
        console.log(this.AdvanceFilter)
        console.log(this.DataInput)
        
      })
    }
    else if (this.Filter == "TeamType") {
      this.service.GetTeams().subscribe(data => {
        this.DataInput = data
        this.AdvanceFilter = data[0].id
        console.log(this.AdvanceFilter)
        console.log(this.DataInput)
        
      })

    }

  

  }
  AdvancedFilterOption(SecondInput: any) {
    this.AdvanceFilter = parseInt(SecondInput.target.value)
    this.DataTable()
    this.TeamSelect(this.AdvanceFilter)
    console.log(SecondInput.target.value)
  }

  FilterByManagerOption(Firstinput: any) {
    this.Filter = "ManagerId"
    this.AdvanceFilter = parseInt(Firstinput.target.value)
    this.DataTable()
    this.Filter = "TeamType"
    console.log(Firstinput.target.value)
  }

  TeamSelect(id: number) {
    this.ManagerList = []
    this.service.GetManager(id).subscribe(data => {
      this.ManagerList = data;
      console.log(this.ManagerList)
    })
  }

  FromDateChange(event: any) {
    this.StartDate = event.target.value
    console.log(event.target.value)
  }
  ToDateChange(event: any) {
    this.EndDate = event.target.value
    console.log(event.target.value)
    this.DataTable()
  }

  DataTable() {
    if (this.AdvanceFilter != 401) {
      if (this.Filter != "JoiningDate") {
        var Query: string = "?" + this.Filter + "=" + this.AdvanceFilter;
      }
      else {
        var Query: string = "?StartDate=" + this.StartDate + "&&EndDate=" + this.EndDate;
      }
      console.log(Query)
      this.service.DisplayUserListByFilter(Query).subscribe(data => {
        this.UserList = data;
      })
    }
    else {
      this.service.GetAllManagerList(id).subscribe(data => {
        this.UserList = data;
      })
    }
  }
    logout() {
      this.service.doLogout()
    }

    Pagination(event: any){
      this.size = parseInt(event.target.value)
      if (this.size != 0) {
        this.LastPage = false
        this.GetPagination(this.size, this.Page)
      }
      else {
        this.RefreshUser
        this.Page = 1
      }
    }

    Click(data: boolean){
      if (data) {
        this.LastPage = false
        this.Page -= 1
      }
      else {
        this.Page += 1
      }
      this.GetPagination(this.size, this.Page)
    }

    GetPagination(Size: number, page: number){
      var Query = "?size=" + Size + "&Page=" + page
      this.service.DisplayUserListByFilter(Query).subscribe(data => {
        this.UserList = data;
        if (this.UserList.length < this.size) {
          this.LastPage = true

        }
      }
      )
    }
  }



function id(id: any) {
  throw new Error('Function not implemented.');
}

