import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonService } from './common.service';
import { DisplayUserComponent } from './user/display-user/display-user.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { FormValidationComponent } from './form-validation/form-validation.component';
import { LoginComponent } from './login/login.component';
import { AuthInterceptor } from './authconfig.interceptor';



@NgModule({
  declarations: [
    AppComponent,
    DisplayUserComponent,
    FormValidationComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [CommonService,
  {
    provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
  }
],
  bootstrap: [AppComponent]
})
export class AppModule { }
