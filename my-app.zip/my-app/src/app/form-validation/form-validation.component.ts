import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { CommonService } from '../common.service';
import { UsernameValidator } from '../Username.validator';
import { Router } from '@angular/router';


@Component({
  selector: 'app-form-validation',
  templateUrl: './form-validation.component.html',
  styleUrls: ['./form-validation.component.css']
})
export class FormValidationComponent implements OnInit {
  @Input() user: any
  registerForm: FormGroup = new FormGroup({});
  submitted = false;
  submit: string = "";
  StatusList: any;
  RoleList: any;
  TeamList: any;
  ManagerList: any
  RoleSelected: any = { Option: 'role.title' }
  formData: FormData = new FormData()
  imgSubmit = false;

  ImageURL: any = "Resources/Images/profile_icon.png"
  // Variable to store shortLink from api response 

  shortLink: string = "";

  loading: boolean = false; // Flag variable 

  file: any = null; // Variable to store file



  constructor(private formBuilder: FormBuilder,
    public service: CommonService,) { }

  ngOnInit(): void {
    if (this.user.userId == 0) {
      this.submit = "AddUser"
    } else {
      this.submit = "EditUser"
    }

    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('^([a-zA-Z]{3,12})$')]],
      lastName: ['', [Validators.required, Validators.pattern('^([a-zA-Z]{1,12})$')]],
      email: ['', [Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]],
      address: ['', [Validators.required]],
      status: [''],
      role: [''],
      joiningdate: [''],
      password: ['', [Validators.required, Validators.pattern('(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!#^~%*?&,.<>"\'\\;:\{\\\}\\\[\\\]\\\|\\\+\\\-\\\=\\\_\\\)\\\(\\\)\\\`\\\/\\\\\\]])[A-Za-z0-9\d$@].{7,}')]],
      currentOrganization: ['', [Validators.required]],
      previousOrganization: ['', [Validators.required]],
      experience: ['', [Validators.required]],
      team: [''],
      manager: [''],
      myCheckbox: new FormControl(false, [Validators.requiredTrue])

    });
    this.service.GetStatus().subscribe(data => {
      this.StatusList = data;
      console.log(data)
    })
    this.service.GetRoles().subscribe(data => {
      this.RoleList = data;
      console.log(data)
    })
    this.service.GetTeams().subscribe(data => {
      this.TeamList = data;
      console.log(data)
      let item = this.TeamList.find((x: { title: any; iD: any; }) => x.title == this.user.team)

      this.service.GetManager(item.id).subscribe(data => {

        this.ManagerList = data;

        console.log(this.ManagerList)

      })
    })
  

    this.registerForm.patchValue({
      firstName: this.user.firstName,
      lastName: this.user.lastName,
      email: this.user.userName,
      address: this.user.address,
      status: this.user.status,
      role: this.user.role,
      joiningdate: this.user.joiningdate,
      password: this.user.password,
      currentOrganization: this.user.currentOrganization,
      previousOrganization: this.user.previousOrganization,
      experience: this.user.experience.toString(),
      team: this.user.team,
      manager: this.user.managerMail,
    })
    this.ImageURL=this.user.filePath

  }
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted=true
    console.log(this.registerForm.invalid)
    let Id = parseInt(this.user.userId)
    let val: any;
    val = {
      UserId: Id,
      FirstName: this.registerForm.get('firstName')?.value,
      LastName: this.registerForm.get('lastName')?.value,
      UserName: this.registerForm.get('email')?.value,
      Address: this.registerForm.get('address')?.value,
      Status: this.registerForm.get('status')?.value,
      Role: this.registerForm.get('role')?.value,
      JoiningDate: this.registerForm.get('joiningdate')?.value,
      Password: this.registerForm.get('password')?.value,
      PreviousOrganization: this.registerForm.get('previousOrganization')?.value,
      CurrentOrganization: this.registerForm.get('currentOrganization')?.value,
      Experience: this.registerForm.get('experience')?.value,
      Team: this.registerForm.get('team')?.value,
      ManagerMail: this.registerForm.get('manager')?.value,
    }

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    if (this.user.userId == 0) {
      this.service.addUserList(val).subscribe(data => {
        console.log(data)
        this.formData.append('UserID', data.userId.toString())

       

        this.service.SaveImage(this.formData).subscribe(res => {

          

          alert(res.statusMessage)
        
        })
      
      })
    
    }
  
    else {
      console.log(val)
          this.service.editUserList(val).subscribe(data => {

            this.formData.append('UserID', data.userId.toString())

            if(this.imgSubmit){
            this.service.SaveImage(this.formData).subscribe(res => {
    
              
    
              alert(res.statusMessage)
            })
          }
          })
          
        }

    this.reset()
  }

    DateSet(date: any){
      date = this.registerForm.get('joiningdate')?.value

    }

    reset() {
      this.registerForm.patchValue({
        firstName: this.user.firstName,
        lastName: this.user.lastName,
        email: this.user.userName,
        address: this.user.address,
        status: this.user.status,
        role: this.user.role,
        joiningdate: this.user.joiningdate,
        password: this.user.password,
        currentOrganization: this.user.currentOrganization,
        previousOrganization: this.user.previousOrganization,
        experience: this.user.experience.toString(),
        team: this.user.team,
        manager: this.user.manager,
      })
      Object.keys(this.registerForm.controls).forEach(key => {
        this.registerForm.controls[key].setErrors(null)
      });
    }
    back() {
      window.location.reload();
    }

    SelectedTeam(event: any) {

      this.ManagerList = []

      let teamtype = event.target.value

      let item = this.TeamList.find((x: { title: any; iD: any; }) => x.title == teamtype)

      this.service.GetManager(item.id).subscribe(data => {

        this.ManagerList = data;

        console.log(this.ManagerList)

      })



    }

    // // // onChange(event: any) {

    // // //   this.file = event.target.files[0];

    // // // }



    // // // // OnClick of button Upload

    // // // onUpload() {

    // // //   this.loading = !this.loading;

    // // //   console.log(this.file);


    // // //   this.service.upload(this.file).subscribe(

    // // //     (event: any) => {

    // // //       if (typeof (event) === 'object') {



    // // //         // Short link via api response

    // // //         this.shortLink = event.link;



    // // //         this.loading = false; // Flag variable

    // // //       }

    // //     }

    // //   );

    // }

    uploadImage(event: any){
      this.imgSubmit = true;
      this.file = <File>event.target.files[0];
      var reader = new FileReader();
      var expandImg: any = document.getElementById("Profile");
      reader.onload = function (e: any) {

        expandImg.src = e.target.result;

        console.log(e.target.result)

      }

      reader.readAsDataURL(event.target.files[0]);

      this.formData.append('profilePicture', this.file);



    }
   
   public createImgPath = (serverPath: string) => {

    console.log(`https://localhost:44394/${serverPath}`)

    return `https://localhost:44394/${serverPath}`;


  }

}