import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormValidationComponent } from './form-validation/form-validation.component';
import { LoginComponent } from './login/login.component';
import { DisplayUserComponent } from './user/display-user/display-user.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
  { path: 'Displayuser', component: DisplayUserComponent, canActivate:[AuthGuard]},
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
